<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <!-- icon -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <?php
    include("connect.php");
    $query="SELECT * FROM `hotelreg` WHERE `hid`=1";
    $confirm=mysqli_query($conn,$query) or die(mysqli_error());
    while($loca=mysqli_fetch_array($confirm))
    {
        $gst=$loca['gst'];
        $add=$loca['add'];
        $contact=$loca['contact'];
        $logo=$loca['logo'];
    }
  ?>

    
<html>
    <style>
        .form-group{
            display:inline-block;
            font-size:17px;
        }
        .table{
            width:93%;
           
            margin-left:30px;
        }
      
        th{
           
            font-size:17px;
        }
        td{
         
            margin-left:5px;
            font-size:17px;
        }
        .table td, .table th {
            padding: 8px;
            margin-left:10px;
        }

    
        p {
            margin-top: 0;
            margin-bottom: 0rem;
        }
        img{
            width:80px;
            height:80px;
            float:left;
           margin-left:10px;
  
        }

        .form-group {
    margin-bottom: 0px;
}

        </style>
    <body>
        <script>
			$(document).ready(function() {
			print();
			});
		</script>
        <form>
            <?php 
                    $cust_id=$_GET['cust_id'];
                    $qry="SELECT `chek_in`.*,`check_out`.* FROM `chek_in`,`check_out` WHERE `chek_in`.`cust_id`=`check_out`.`cust_id` AND `chek_in`.`cust_id`='$cust_id' ";
                    $exc=mysqli_query($conn,$qry);
                    while($row=mysqli_fetch_array($exc))
                    {
                        $full=$row['full'];
                        $phone=$row['phone'];
                        $cmp=$row['cmp'];
                        $cgst=$row['gst'];
                        $id=$row['id'];
                        
                        $rent=$row['rent'];
                        $famt=$row['famt'];
                        $coast=$row['coast'];
                        $adv=$row['advance'];
                        $out=$row['checkout'];
                        $check=$row['datecheck'];
                        

                    }
                
        	?>
            <div class="card container" >
                <div class="card-body">            
                    <div class="panel-heading">                       
                    <div class="panel-title">     
                          <img src="<?php echo $logo ?>">
                                <center><P style="float:right;"><b>GSTIN:</b><?php echo $gst?></p><h5 >Shiva Loage</h5> </center>
                              <center><h4 style="margin-right:170px;"></h4> </center>
                              <center>
                                <div style="margin-right:170px;">
                                    <p><?php echo $add?></p>
                                    <p style="margin-left:100px;">Mobile Number :- <?php echo $contact?></p> </center>
                                </div>
                                    <hr>
                      	</div>
                    </div><br>
                        <?php $curdate = date("d/m/Y"); ?>   
                        <div class="row">
                            <div class="col-sm-8" style="margin-left: 30px;">
                                <div class="form-group">
                                    <label><b>Customer_id: </b><?php echo $cust_id; ?></label>
                                </div>
                            </div>
                            <div class="col-offset-sm-4" style="margin-left: 30px;">
                                <div class="form-group">
                                    <label><b>Invoice No: </b><?php echo $id; ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-8" style="margin-left: 30px;">
                                <div class="form-group">
                                    <label><b>Mr/Miss: </b> <?php echo $full ?></label>
                                </div>
                            </div>
                            <div class="col-offset-sm-4" style="margin-left: 30px;">
                                <div class="form-group">
                                    <label><b>Mobile: </b> <?php echo $phone; ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-8" style="margin-left: 28px;">
                                <div class="form-group">
                                    <label><b>Company_name: </b> <?php echo $cmp; ?></label>
                                </div>
                            </div>
                            <div class="col-offset-sm-4" style="margin-left: 30px;">
                                <div class="form-group">
                                    <label><b>Customer-GST: </b> <?php echo $cgst; ?></label>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="panel-body" >
                            <!-- table here -->
                            <table class="table table-bordered ">
                                <tr>
                                <th>S.No</th>
                                    <th>Checkin</th>
                                    <th>Checkout</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    
                                </tr>
                                <tr>
                                    <td rowspan="8x">1</td> 
                                    <td rowspan="8x"><?php echo $check?></td>
                                    <td rowspan="8x"><?php echo $out?></td>
                                    
 
                              
                                    <td>Room Charge:</td>
                                   <td><?php echo $total=$rent+$coast;?></td>
                                </tr>
                                <?php if($famt>0)
                                        {
                                            ?>
                                                <tr>
                                                    <td>Food Charge</td>
                                                    <td><?php echo $famt; ?></td>
                                                </tr>
                                            <?php
                                        }
                                ?>
                                
                                <tr>
                                    <?php $tax=$rent+$coast+$famt;
                                            $tax1=$tax*18/100; 
                                            $final=($total+$famt)+$tax1?>
                                    <td>GST(18%):</td>
                                   <td><?php echo $tax1?></td>
                                </tr>
                                <?php if($adv>0)
                                        {
                                            ?>
                                                <tr>
                                                    <td>Diposit</td>
                                                    <td><?php echo $adv?></td>
                                                </tr>
                                            <?php
                                        }
                                ?> 
                                <tr>
                                
                                    <td class="h6">Payble:</td>
                                   <td><?php echo $final-$adv; ?></td>
                                </tr>
                               
                         </table><hr>
                         <!-- <div class="row">
                            <b style="font-size:14px;margin-left:16px;">Terms & Conditions..</b><br>                        
                         </div>

                         <div class="row">
                            <p style="font-size:14px;margin-left:25px;">1. I agree to abide by the rules of conduct, behavior, dress code, equipment usage.</p><br>
                         </div>

                         <div class="row">
                            <p style="font-size:14px;margin-left:25px;">2. The membership fees are not refundable. </p><br>                        
                         </div>

                         <div class="row">
                            <p style="font-size:14px;margin-left:25px;">3. Members are not permitted to bring Children into the Gym. </p><br>                          
                         </div>

                         <div class="row">
                            <p style="font-size:14px;margin-left:25px;">4. Loss and damage to gym equipment intentfully to be bariede by the member. </p><br>                          
                         </div>

                         <div class="row">
                            <p style="font-size:14px;margin-left:25px;">5. Any unhealthy activity lost by the member is noticed then discipline action will ne taken. </p><br>                          
                         </div> -->

                   </div>
                </div>
        </form>
    </body>
    
</html>

