-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2023 at 09:27 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lodge`
--

-- --------------------------------------------------------

--
-- Table structure for table `check_out`
--

CREATE TABLE `check_out` (
  `id` int(10) NOT NULL,
  `checkout` datetime NOT NULL,
  `famt` double NOT NULL,
  `total` double NOT NULL,
  `cust_id` int(10) NOT NULL,
  `pay` varchar(20) NOT NULL,
  `rno` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `check_out`
--

INSERT INTO `check_out` (`id`, `checkout`, `famt`, `total`, `cust_id`, `pay`, `rno`) VALUES
(1, '2023-02-20 01:46:00', 500, 1750, 1, 'Online', 'A1');

-- --------------------------------------------------------

--
-- Table structure for table `chek_in`
--

CREATE TABLE `chek_in` (
  `cust_id` int(10) NOT NULL,
  `full` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `datecheck` datetime NOT NULL,
  `type` varchar(10) NOT NULL,
  `room` varchar(10) NOT NULL,
  `rent` double NOT NULL,
  `bed` double NOT NULL,
  `coast` double NOT NULL,
  `status` int(10) NOT NULL,
  `total` double NOT NULL,
  `advance` double NOT NULL,
  `remain` double NOT NULL,
  `phone` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chek_in`
--

INSERT INTO `chek_in` (`cust_id`, `full`, `email`, `datecheck`, `type`, `room`, `rent`, `bed`, `coast`, `status`, `total`, `advance`, `remain`, `phone`) VALUES
(1, 'Akash Baleshi Jogani', 'akashjogani93@gmail.com', '2023-12-31 22:59:00', '12 Hour', 'A1', 1250, 1, 100, 0, 1250, 100, 0, '9742020863'),
(2, 'Mahesh K Chougule', 'mahesh90@gmail.com', '2023-02-20 00:33:00', '24 Hour', 'A2', 2500, 0, 0, 0, 2500, 0, 0, '7676801529');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_id` int(10) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `amt` double NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_id`, `room_no`, `amt`, `status`) VALUES
(1, 'A1', 500, 1);

-- --------------------------------------------------------

--
-- Table structure for table `freshup`
--

CREATE TABLE `freshup` (
  `id` int(11) NOT NULL,
  `checkin` varchar(30) NOT NULL,
  `datetime` datetime NOT NULL,
  `roomno` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `amt` double NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(10) NOT NULL,
  `category` varchar(30) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `amt` double NOT NULL,
  `type1` varchar(20) NOT NULL,
  `amt1` double NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `category`, `room_no`, `type`, `amt`, `type1`, `amt1`, `status`) VALUES
(2, 'Regular', 'A1', '12 Hour', 1250, '24 Hour', 2500, 0),
(3, 'Regular', 'A2', '12 Hour', 1250, '24 Hour', 2500, 1),
(4, 'Family', 'F1', '12 Hour', 2500, '24 Hour', 5000, 0),
(5, 'Family', 'F2', '12 Hour', 2600, '24 Hour', 4000, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `check_out`
--
ALTER TABLE `check_out`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chek_in`
--
ALTER TABLE `chek_in`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `freshup`
--
ALTER TABLE `freshup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `check_out`
--
ALTER TABLE `check_out`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chek_in`
--
ALTER TABLE `chek_in`
  MODIFY `cust_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `food_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `freshup`
--
ALTER TABLE `freshup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
