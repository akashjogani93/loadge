
<?php
$servername="localhost";
$username="root";
$password="";
$db="lodge";
$conn=mysqli_connect($servername,$username,$password,$db);
?>

<?php
// $servername="localhost";
// $username="evontest_vffgym";
// $password="vff123";
// $db="evontest_vffgym";
// $conn=mysqli_connect($servername,$username,$password,$db);
?>