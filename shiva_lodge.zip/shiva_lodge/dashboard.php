<?php include("sidebar.php"); 
include("connect.php"); 
$r=0;?>
<style>
    body {
        /* background-image: linear-gradient(to bottom , #248ea9 40%, #fafdcb 40%); Standard syntax (must be last) */
        background-color:rgba(233, 245, 250, 1);
        /* background-color: #946000; */
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: cover;
        overflow-y: hidden;
        font-family: 'Ropa Sans', sans-serif;
    }
    .abc{
        background-color:rgba(96, 194, 142, 1);
    }
    .def{
        background-color:rgba(245, 89, 79, 1);
    }
</style>
<?php 
    $query="SELECT DISTINCT * FROM `room` WHERE `status`=0 ORDER BY `id` ASC";
    $confirm=mysqli_query($conn,$query) or die(mysqli_error());
    $co=mysqli_query($conn,$query) or die(mysqli_error());
    
    $quer="SELECT DISTINCT * FROM `room` WHERE `status`=1 ORDER BY `id` ASC";
    $conf=mysqli_query($conn,$quer) or die(mysqli_error());
    $con=mysqli_query($conn,$quer) or die(mysqli_error());
    
?>

<!-- sidebar-wrapper  -->
<main class="page-content" >
    <div class="container-fluid" >
    <div class="d-flex justify-content-between">
            <!-- <h2 class="" style=" font-weight: 600;color:white; ">Dashboard</h2> -->
        </div><br><br><br>
          <!-- Small boxes (Stat box) -->
          <div class="row">
        <div class="col">
            <div class="conatiner">
                <div class="row" style="margin-left:auto; margin-right:auto;width:100%; justify-content:center;">
                    <div class="col-6 col-sm-3" >
                        <div class="p-sm-3" style="background-color:rgba(127, 32, 84, 0.6);">
                         <h4 style="color:white;">Available</h4>
                         <?php
                            $r=0;
                            while($loca=mysqli_fetch_array($co))
                            {
                                $r=$r+1;
                            }
                            echo '<h4 style="color:white;">'.$r.'</h4>';
                         ?>
                         
                         
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="p-sm-3" style="background-color:rgba(45, 80, 78, 0.6);">
                            <h4 style="color:#fff;">Boking</h4>
                            <?php
                                $r=0;
                                while($loca=mysqli_fetch_array($con))
                                {
                                    $r=$r+1;
                                }
                                echo '<h4 style="color:white;">'.$r.'</h4>';
                            ?>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
            <div class="conatiner pt-2 mt-4">
              <CENTER>  <h6><b>AVAILABLE ROOMS</b></h6></CENTER>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <?php 
                                $r=0;
                                while($loca=mysqli_fetch_array($confirm))
                                {
                                    $r=$r+1;
                                    ?>
                                    
                                        <div class="col-sm-4">
                                            <div class="p-3 abc m-1">
                                                <h6 style="color:#fff;">
                                                    <?php echo $loca['room_no']; ?>
                                                </h6>
                                            </div>
                                        </div>
                                    <?php
                                }
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <?php 
                                $r=0;
                                while($loca=mysqli_fetch_array($conf))
                                {
                                    ?>
                                        <div class="col-sm-4">
                                            <div class="p-3 def m-1">
                                                <h6 style="color:#fff;">
                                                    <?php echo $loca['room_no']; ?>
                                                </h6>
                                            </div>
                                        </div>
                                    <?php
                                }
                            ?>
                        </div>
                    </div>
                </div>

                <?php $i = 10;
                while ($i > 5) {
                ?>
                    <!-- <div class="row">

                        <div class="col-sm-2">
                            <div class="p-3 abc m-1">
                                <h6 style="color:#fff;">
                                    A<?php echo $i; ?>
                                </h6>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="p-3 abc m-1">
                                <h6 style="color:#fff;">
                                    A<?php echo $i; ?>
                                </h6>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="p-3 abc m-1">
                                <h6 style="color:#fff;">
                                    A<?php echo $i; ?>
                                </h6>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="p-3 abc m-1">
                                <h6 style="color:#fff;">
                                    A<?php echo $i; ?>
                                </h6>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="p-3 def m-1">
                                <h6 style="color:#fff;">
                                    A<?php echo $i; ?>
                                </h6>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="p-3 abc m-1">
                                <h6 style="color:#fff;">
                                    A<?php echo $i; ?>
                                </h6>
                            </div>
                        </div>
                    </div> -->
                <?php
                    $i--;
                } ?>


            </div>
        </div>
    </div>
        
    </div>
    <div class="hrs" style="border-top:1px white solid;"></div>

    <!-- Countdown 
    <div class="col-md-12" style="margin-top:20px;">
        <img class="img-responsive img-thumbnail" style="height:450px; width:800px;" src="assets/image/dbs.jpg">
    </div>
    // Countdown -->


</main>

 <!-- footer -->
<div id="sticky-footer" class="container-fluids">
           <div class="wthree-copyright m-3">
            <p class="text-center" style="font-weight:600; color:white;"> Design & Developed By Evon IT solution..</p>
           </div>
   </div>
  <!-- / footer -->
  <?php
// include("./footer.php");
?>
</div>
</div>



</body>

</html>

