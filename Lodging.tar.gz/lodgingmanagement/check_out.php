<?php include("sidebar.php");
include("connect.php");

$cnt = 0;
        $sql = "SELECT max(id) FROM check_out";
        $retval = mysqli_query($conn, $sql );
        
        if(! $retval ) {
            die('Could not get data: ' . mysqli_error($conn));
        }
        while($row = mysqli_fetch_assoc($retval)) {
            $cnt=$row['max(id)'];
            $cnt++;
        }
?>
<style>
    .class{
        font-size:14px;

    }
    form {
    padding: 30px;
}
.container{
    background-color:rgba(255, 255, 255, 0.4);
}

.infos{
    background-color:white;
}
th{
    padding-right:20px;
}
th, td {
padding: 5px;
text-align: left;
}
#profile-table tr th, tr td {
    border:none;
}
.group-form {
    margin-top:17px;
}
</style>
<div class="page-content container-fluid" style="background-color:rgba(233, 245, 250, 1);">
    <div class="footer"style="background-color:rgba(233, 245, 250, 1);">
        <div class="d-flex justify-content-between">
             <h2 class="" style="font-size:36px; font-weight: 600">CUSTOMER CHECK-OUT</h2>
        </div>
     
    </div>
</div>

                    
<main class="page-content"style="background-color:rgba(233, 245, 250, 1);">
    <div class="container">
        <form action="checkout_submit.php" method="post" enctype="multipart/form-data"  >
            <div class="row lefts">
                <div class="col-md-4"style="back-">
                <div class="group-form ">
                        <label class="form_label" for="company_name"> Bill No</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo $cnt; ?>" readonly placeholder=""/>
                    </div> 
                    <div class="group-form ">
                        <label class="form_label" for="company_name"> Room No</label>
                            <select class="form-control form-control-sm" required name="rno" id="rno" onchange="diver1()">
                                <option value="">Select Number</option>
                                <?php
                                        $query="SELECT DISTINCT `room_no` FROM `room` WHERE `status`=1 ORDER BY `id` ASC";
                                        $confirm=mysqli_query($conn,$query) or die(mysqli_error());
                                        while($loca=mysqli_fetch_array($confirm))
                                    {?>
                                        <option><?php echo $loca['room_no']; ?></option>
                                    <?php   }   ?>
                            <select>
                    </div>
                    <div class="group-form ">
                        <label class="form_label" for="company_name"> Name</label>
                        <input type="text" class="form-control form-control-sm" id="name" readonly placeholder=""/>
                    </div> 
                    <div class="group-form ">
                        <label class="form_label" for="company_name"> Customer id</label>
                        <input type="text" class="form-control form-control-sm" id="cust_id" name="cust_id" readonly placeholder=""/>
                    </div> 
                    
                    <div class="group-form ">
                        <label class="form_label" for="company_name"> Room Rent</label>
                        <input type="text" class="form-control form-control-sm" id="rent" readonly placeholder=""/>
                    </div> 
                    <div class="group-form ">
                        <label class="form_label" for="company_name">Extra Bed Cost</label>
                        <input type="text" class="form-control form-control-sm" id="bed" readonly placeholder=""/>
                    </div> 
                    <!-- <div class="group-form ">
                        <label class="form_label" for="company_name"> Check-Out Type</label>
                        <input type="text" class="form-control form-control-sm" readonly required   placeholder=""/>
                    </div> 
                    <div class="group-form ">
                        <label class="form_label" for="company_name"> Check-Out Date</label>
                        <input type="text" class="form-control form-control-sm" readonly required   placeholder=""/>
                    </div> -->
                    <div class="group-form ">
                        <label class="form_label" for="company_name">Food Amount</label>
                        <input type="text" class="form-control form-control-sm" id="food" name="food" readonly placeholder=""/>
                    </div>
                    
                </div>

                <div class="col-md-8">
                    <div class="row">
                        <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Basic Amount</label>
                            <input type="text" class="form-control form-control-sm" id="basic" required  placeholder=""/>
                        </div> 
                        <!--   -->
                        <!-- <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Remaning Amount</label>
                            <input type="text" class="form-control form-control-sm" id="remain" required   placeholder=""/>
                        </div> -->
                        <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Total Amount</label>
                            <input type="text" class="form-control form-control-sm" id="total1" name="total1" required   placeholder=""/>
                        </div>
                    </div>

                    <div class="row">
                        <!-- <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Payable Amount</label>
                            <input type="text" class="form-control form-control-sm"  required   placeholder=""/>
                        </div>  -->
                        <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Diposit Amount</label>
                            <input type="text" class="form-control form-control-sm" id="adv" required  placeholder=""/>
                        </div>
                        <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Payable Amount</label>
                            <input type="text" class="form-control form-control-sm"  id="total" required   placeholder=""/>
                        </div>
                        
                    </div>

                    <div class="row">
                        <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Check Out date & Time</label>
                            <input type="datetime-local" class="form-control form-control-sm" name="date" id="date" required>
                        </div>
                        <div class="group-form col-md-6">
                            <label class="form_label" for="company_name">Payment Type</label><br>
                            <input type="radio" checked id="contactChoice1" name="contact" value="Online" />
                            <label for="contactChoice1" style="margin-right:20px;">Online</label>

                            <input type="radio" id="contactChoice2" name="contact" value="Case" />
                            <label for="contactChoice2">Cash</label>
                        </div> 
                    </div>

                    <div class="row mt-2">
                        <div class="group-form-btn col-md-12">
                        
                           <center> <button type="submit" name="checkout" class="btn btn-sm btn-primary col-md-4">Update</button></center>
                        
                    </div>
                    

                    
                </div>
            </div>
        </form>
</div>
</main>

<script>
    function diver1()
    {
        // alert('hii');
        // var rno=document.getElementbyId('rno').value;
        var rno = document.getElementById('rno').value;
        let log=$.ajax({
            url: 'checkout_ajax.php',
            type: "POST",
            dataType:'json',
            data:  {
                rno: rno,
            }
            , success:function(data) {
                $("#name").val(data[0]);
                $("#cust_id").val(data[1]);
                $("#rent").val(data[2]);
                $("#bed").val(data[3]);
                $("#food").val(data[4]);
                $("#remain").val(data[6]);
                $("#adv").val(data[5]);

                let basic=parseFloat(data[2])+parseFloat(data[3])+parseFloat(data[4]);
                $("#basic").val(basic);
                let total1=((basic*18)/100)+basic;
                $("#total1").val(total1);
                let total=total1-parseFloat(data[5]);
                $("#total").val(total);
                console.log(data)
            }
        });console.log(log)
    }
</script>
