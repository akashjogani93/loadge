
<?php
$servername="localhost";
$username="evontest_shiva";
$password="Shiva@@@123";
$db="evontest_shiva";
$conn=mysqli_connect($servername,$username,$password,$db);
?>

<?php
// $servername="localhost";
// $username="evontest_vffgym";
// $password="vff123";
// $db="evontest_vffgym";
// $conn=mysqli_connect($servername,$username,$password,$db);
?>